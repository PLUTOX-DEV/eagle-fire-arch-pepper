"use client";

import { useEffect, useState } from "react";

const TG = "https://t.me/hoodoween";
const X = "https://x.com/Hoodoween_RBH";

function Svg({ children, className = "" }) {
  return <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">{children}</svg>;
}

function TelegramIcon() {
  return <Svg><path fill="currentColor" d="M21.7 3.3 18.4 20c-.25 1.18-.93 1.47-1.88.92l-5.2-3.83-2.51 2.42c-.28.28-.51.51-1.05.51l.37-5.3 9.65-8.72c.42-.37-.09-.58-.65-.21L5.2 13.04.08 11.43c-1.11-.35-1.13-1.11.23-1.64L20.32 2.1c.93-.34 1.74.21 1.38 1.2Z"/></Svg>;
}
function XIcon() {
  return <Svg><path fill="currentColor" d="M18.9 2H22l-6.77 7.74L23.2 22h-6.24l-4.88-6.38L6.5 22H3.4l7.24-8.28L2.8 2h6.4l4.41 5.83L18.9 2Zm-1.09 17.9h1.72L8.29 4.02H6.44L17.81 19.9Z"/></Svg>;
}
function Arrow() {
  return <Svg><path d="M5 12h13M13 6l6 6-6 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/></Svg>;
}
function Feather() {
  return <Svg><path fill="currentColor" d="M20.7 3.3C15.4 2.4 9.2 4.5 6.2 7.5 3.9 9.8 3 13.2 3.7 16.1l-2 4.1 4.1-2c2.9.7 6.3-.2 8.6-2.5 3-3 5.1-9.2 4.3-14.4Zm-2.2 3.1-8.1 8.1-3.4.7.7-3.4 8.1-8.1c1-.6 1.9-.8 2.7-.7Z"/></Svg>;
}
function Calendar() {
  return <Svg><rect x="3" y="4" width="18" height="17" rx="2" stroke="currentColor" strokeWidth="1.8"/><path d="M7 2v4M17 2v4M3 9h18" stroke="currentColor" strokeWidth="1.8"/><path d="M7 13h2M12 13h2M17 13h1M7 17h2M12 17h2" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round"/></Svg>;
}

function Countdown() {
  const target = new Date("2026-10-12T00:00:00-07:00").getTime();
  const [t, setT] = useState({d: 0, h: 0, m: 0, s: 0});
  useEffect(() => {
    const tick = () => {
      const diff = Math.max(0, target - Date.now());
      const n = Math.floor(diff / 1000);
      setT({ d: Math.floor(n/86400), h: Math.floor((n%86400)/3600), m: Math.floor((n%3600)/60), s: n%60 });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  const p = n => String(n).padStart(2, "0");
  return (
    <div className="timer">
      {[["DAYS",t.d],["HOURS",t.h],["MINUTES",t.m],["SECONDS",t.s]].map(([k,v]) =>
        <div className="timer-cell" key={k}><b>{p(v)}</b><span>{k}</span></div>
      )}
    </div>
  );
}

export default function Home() {
  return (
    <main>
      <div className="top-glow"/>
      <header className="header">
        <a href="#home" className="logo">
          <span className="logo-pumpkin">🎃</span>
          <span>Hoodoween</span>
        </a>
        <nav>
          <a className="active" href="#home">Home</a>
          <a href="#story">About</a>
          <a href="#tokenomics">Tokenomics</a>
          <a href="#fees">Fees</a>
          <a href="#community">Community</a>
          <a href="#roadmap">Roadmap</a>
        </nav>
        <div className="head-right">
          <a className="circle" href={TG} target="_blank" rel="noreferrer"><TelegramIcon/></a>
          <a className="circle" href={X} target="_blank" rel="noreferrer"><XIcon/></a>
          <div className="ca-chip">
            <span className="mini-pumpkin">🎃</span>
            <div><small>CA: COMING SOON</small><b>BY 12 OCTOBER</b></div>
          </div>
        </div>
      </header>

      <section className="hero" id="home">
        <div className="hero-left">
          <div className="tiny-title"><i/> HALLOWEEN HAS ENTERED THE HOOD</div>
          <div className="welcome">Welcome to</div>
          <h1><em>$</em>HOODO<span>W</span>EEN</h1>
          <h2><strong>Hoodoween:</strong> Robinhood First ever<br/>Halloween celebration and memecoin.</h2>
          <div className="short-line"/>
          <p className="intro">
            This is Robinhood first Halloween ever.<br/>
            Hoodoween is the name of it First Halloween<br/>
            celebration and token ever...
          </p>

          <div className="signal">
            <div className="signal-icon"><XIcon/></div>
            <div className="signal-copy">
              <p>There is a 60% chance of Robinhood<br/>tweeting <strong>"Happy Hoodoween"</strong><br/>on Halloween.</p>
            </div>
            <div className="gauge"><span>60%</span></div>
          </div>

          <div className="scare">🎃 &nbsp; Don't get scared of the potential<br className="mobile-break"/> of Hoodoween &nbsp;🎃 👻</div>
        </div>

        <div className="hero-right">
          <div className="moon"/>
          <div className="hero-art">
            <img src="/images/hoodoween-hero.png" alt="Hoodoween Halloween pumpkin character"/>
          </div>
        </div>
      </section>

      <section className="countdown-band" id="roadmap">
        <div className="count-label">
          <h2>THE COUNTDOWN</h2>
          <div><span/> CA LAUNCH 🎃</div>
        </div>
        <Countdown/>
        <div className="launch-chip">
          <span>🎃</span><div><b>CA: COMING SOON</b><small>BY 12 OCTOBER</small></div>
        </div>
      </section>

      <section className="feature-grid">
        <article><div className="feature-icon">🎃</div><span>01</span><h3>THE FIRST</h3><p>Robinhood's first ever Halloween celebration and memecoin.</p></article>
        <article className="green-card"><div className="feature-icon"><Feather/></div><span>02</span><h3>COMMUNITY</h3><p>Built by the people.<br/>For the people.<br/>Hoodoween.</p></article>
        <article><div className="feature-icon">🚀</div><span>03</span><h3>BIG POTENTIAL</h3><p>A memecoin with real culture, real energy, real community.</p></article>
        <article className="green-card"><div className="feature-icon">👻</div><span>04</span><h3>CA EXCHANGE</h3><p>Coming soon<br/>by 12 October.</p><div className="date"><Calendar/> 12 OCTOBER</div></article>
      </section>

      <section className="story-layout section" id="story">
        <div className="story-image">
          <img src="/images/graveyard.png" alt="Hoodoween graveyard artwork"/>
        </div>
        <div className="story-copy">
          <div className="tiny-title">THE STORY</div>
          <h2>THE HOOD IS READY<br/>FOR HALLOWEEN.</h2>
          <p>Robinhood is known for breaking the rules. This Halloween, they're not just watching from the sidelines...</p>
          <p>Hoodoween is a community-driven celebration of freedom, culture, memes and the people that make it all possible.</p>
          <div className="script">Same Robinhood.<br/>New kind of holiday.</div>
        </div>
        <div className="token-box" id="tokenomics">
          <div className="tiny-title">TOKENOMICS</div>
          <h3>$HOODOWEEN</h3>
          <div className="ticker-badge">$HOODOWEEN</div>
          <div className="token-row"><span>Holder Airdrops</span><b>30% FEES</b></div>
          <div className="token-row"><span>Buybacks</span><b>20% FEES</b></div>
          <div className="token-row"><span>Donations</span><b>20% FEES</b></div>
          <div className="token-row"><span>Marketing</span><b>30% FEES</b></div>
          <div className="token-row"><span>Dev Holdings</span><b>2.5% SUPPLY</b></div>
          <div className="no-sell">✓ NO TOKEN SALES FOR MARKETING</div>
          <div className="token-ca">🎃 <span>CA: COMING SOON<br/><small>BY 12 OCTOBER</small></span></div>
        </div>
      </section>

      <section className="fees-section" id="fees">
        <div className="fees-head">
          <div className="tiny-title"><i/> FEES BREAKDOWN</div>
          <h2>EVERY FEE HAS A PURPOSE.</h2>
          <p>$HOODOWEEN routes fees across holders, buybacks, donations and marketing.</p>
        </div>
        <div className="fee-grid">
          <article className="fee-card orange"><strong>30%</strong><span>HOLDER AIRDROP</span><p>30% of fees goes to airdrops for holders.</p></article>
          <article className="fee-card green"><strong>20%</strong><span>BUYBACKS</span><p>20% of fees goes toward buybacks.</p></article>
          <article className="fee-card blue"><strong>20%</strong><span>DONATIONS</span><p>20% of fees goes to donations.</p></article>
          <article className="fee-card purple"><strong>30%</strong><span>MARKETING</span><p>30% of fees supports marketing.</p></article>
        </div>
        <div className="dev-note"><span>DEV HOLDINGS</span><b>2.5%</b><p>of total token supply</p><em>So there are no dev token sales for marketing and related expenses.</em></div>
      </section>

      <section className="community" id="community">
        <div className="community-left">
          <div className="big-logo">🎃 <span><em>$</em>HOODO<span>W</span>EEN</span></div>
          <div className="tagline">— &nbsp; SCARY GOOD POTENTIAL &nbsp; —</div>
        </div>
        <div className="join">
          <div className="social-row">
            <a className="circle big" href={TG} target="_blank" rel="noreferrer"><TelegramIcon/></a>
            <a className="circle big" href={X} target="_blank" rel="noreferrer"><XIcon/></a>
          </div>
          <b>Join the community</b>
          <span>↗</span>
          <div className="handles"><a href={TG} target="_blank" rel="noreferrer">t.me/hoodoween</a><a href={X} target="_blank" rel="noreferrer">x.com/Hoodoween_RBH</a></div>
        </div>
        <div className="community-art"><img src="/images/hoodoween-character.png" alt="Hoodoween character"/></div>
      </section>

      <footer>
        <b>$HOODOWEEN</b>
        <span>Robinhood First ever Halloween celebration and memecoin.</span>
        <small>Not affiliated with Robinhood Markets, Inc. This is a community meme project.</small>
      </footer>
    </main>
  );
}
