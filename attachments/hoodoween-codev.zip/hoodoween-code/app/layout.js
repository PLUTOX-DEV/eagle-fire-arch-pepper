import "./globals.css";

export const metadata = {
  title: "$HOODOWEEN — Scary Good Potential",
  description: "Hoodoween — a Halloween-themed community memecoin landing page.",
  icons: { icon: "/images/pumpkin.png" },
  openGraph: {
    title: "$HOODOWEEN — Hoodoween",
    description: "Don't get scared of the potential of Hoodoween.",
    images: ["/images/hoodoween-hero.png"]
  }
};

export default function RootLayout({ children }) {
  return <html lang="en"><body>{children}</body></html>;
}
