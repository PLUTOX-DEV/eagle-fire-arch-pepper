# $HOODOWEEN

Screenshot-matched dark Halloween landing page built with Next.js and plain CSS.

## Included
- Screenshot-inspired header, hero, countdown, feature cards, story, tokenomics and footer
- Exact supplied Telegram and X links
- No wallet connect
- CA placeholder: Coming Soon / 12 October
- Responsive desktop and mobile layouts
- Vercel-ready

## Run
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm start
```

## Deploy
Push to GitHub and import the repository into Vercel, or upload the project through Vercel's deployment UI.

## Official links
Telegram: https://t.me/hoodoween
X: https://x.com/Hoodoween_RBH

## Important
The tokenomics values are intentionally marked TBA because no final tokenomics were supplied.
The site states that it is not affiliated with Robinhood Markets, Inc.


## Supplied tokenomics
- Ticker: $HOODOWEEN
- 30% of fees: holder airdrops
- 20% of fees: buybacks
- 20% of fees: donations
- 30% of fees: marketing
- Dev holdings: 2.5% of total token supply
- Site copy states: no dev token sales for marketing and related expenses

These figures are displayed as project-provided information and should be verified before launch.
