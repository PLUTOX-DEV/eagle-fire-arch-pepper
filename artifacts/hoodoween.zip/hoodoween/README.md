# $HOODOWEEN

Robinhood's first Halloween celebration memecoin landing page.

- Ticker: `$Hoodoween`
- CA launch: 12 October 2026
- Telegram: https://t.me/hoodoween
- X: https://x.com/Hoodoween_RBH

Open `index.html` in a browser, or drop the folder on any static host.

Not affiliated with Robinhood Markets, Inc. This is a community memecoin project.
