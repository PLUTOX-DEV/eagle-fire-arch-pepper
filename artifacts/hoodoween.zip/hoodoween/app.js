const TARGET = new Date("2026-10-12T00:00:00-07:00").getTime();

function pad(n) {
  return String(n).padStart(2, "0");
}

function tick() {
  const n = Math.max(0, Math.floor((TARGET - Date.now()) / 1000));
  const t = {
    DAYS: Math.floor(n / 86400),
    HOURS: Math.floor((n % 86400) / 3600),
    MINUTES: Math.floor((n % 3600) / 60),
    SECONDS: n % 60,
  };
  for (const [label, value] of Object.entries(t)) {
    const el = document.querySelector(`[data-unit="${label}"]`);
    if (el) el.textContent = pad(value);
  }
}
tick();
setInterval(tick, 1000);

const header = document.querySelector(".site-header");
const menuBtn = document.querySelector(".menu-btn");
const sheet = document.querySelector(".mobile-sheet");
let open = false;

function setOpen(next) {
  open = next;
  sheet.classList.toggle("open", open);
  header.classList.toggle("menu-open", open);
  document.body.classList.toggle("menu-open", open);
  document.body.style.overflow = open ? "hidden" : "";
  sheet.setAttribute("aria-hidden", open ? "false" : "true");
  if (open) sheet.removeAttribute("inert");
  else sheet.setAttribute("inert", "");
  menuBtn.setAttribute("aria-expanded", String(open));
  menuBtn.setAttribute("aria-label", open ? "Close menu" : "Open menu");
  menuBtn.innerHTML = open
    ? '<svg viewBox="0 0 24 24" fill="none" class="size-[1.15em]"><path d="M6 6l12 12M18 6 6 18" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>'
    : '<svg viewBox="0 0 24 24" fill="none" class="size-[1.15em]"><path d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>';
}

menuBtn.addEventListener("click", () => setOpen(!open));
sheet.querySelectorAll("a").forEach((a) => a.addEventListener("click", () => setOpen(false)));

window.addEventListener(
  "scroll",
  () => header.classList.toggle("is-scrolled", window.scrollY > 8),
  { passive: true },
);

const ids = ["home", "about", "tokenomics", "fees", "community", "roadmap"];
const navLinks = document.querySelectorAll(".desk-nav a, .mobile-sheet nav a");
const io = new IntersectionObserver(
  (entries) => {
    const vis = entries.filter((e) => e.isIntersecting).sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
    if (!vis) return;
    navLinks.forEach((a) => a.classList.toggle("active", a.getAttribute("href") === `#${vis.target.id}`));
  },
  { rootMargin: "-28% 0px -58% 0px", threshold: [0.1, 0.25, 0.5] },
);
ids.forEach((id) => {
  const el = document.getElementById(id);
  if (el) io.observe(el);
});
